//
//  Model.swift
//  CalculatorApp
//
//  Created by Ingride Youadeu on 2024-09-26.
//

import Foundation
