//
//  CalculatorAppApp.swift
//  CalculatorApp
//
//  Created by Ingride Youadeu on 2024-09-26.
//

import SwiftUI

@main
struct CalculatorAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
